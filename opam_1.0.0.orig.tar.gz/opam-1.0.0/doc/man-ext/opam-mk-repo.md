% OPAM(1) opam 0.9.3 | OPAM Manual
% OCamlPro
% 20/02/2013

# NAME

opam-mk-repo - a Tool to Build OPAM Repositories

# DESCRIPTION

See *opam-mk-repo --help* for me information.
# SEE ALSO

**opam**(1)

# LINKS

* **http://opam.ocamlpro.com**

# OPAM

Part of the opam(1) suite
