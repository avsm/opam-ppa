% OPAM(1) opam 0.9.3 | OPAM Manual
% OCamlPro
% 20/02/2013

# NAME

opam-check - a Tool check that OPAM repositories are consistent

# DESCRIPTION

See *opam-check --help* for me information.

# SEE ALSO

**opam**(1)

# LINKS

* **http://opam.ocamlpro.com**

# OPAM

Part of the opam(1) suite
